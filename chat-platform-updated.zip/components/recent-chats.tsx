import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function RecentChats() {
  // This would normally come from an API
  const chats = [
    {
      id: 1,
      user: {
        id: 101,
        name: "Emma Wilson",
        avatar: "/placeholder.svg?height=40&width=40",
        online: true,
      },
      lastMessage: {
        text: "Hey, are you free to video chat later today?",
        timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
        isRead: true,
      },
    },
    {
      id: 2,
      user: {
        id: 102,
        name: "James Rodriguez",
        avatar: "/placeholder.svg?height=40&width=40",
        online: false,
      },
      lastMessage: {
        text: "I saw your new profile photo, it looks great!",
        timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
        isRead: false,
      },
    },
    {
      id: 3,
      user: {
        id: 103,
        name: "Sophia Chen",
        avatar: "/placeholder.svg?height=40&width=40",
        online: true,
      },
      lastMessage: {
        text: "Thanks for the recommendation, I'll check it out!",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
        isRead: true,
      },
    },
    {
      id: 4,
      user: {
        id: 104,
        name: "Michael Brown",
        avatar: "/placeholder.svg?height=40&width=40",
        online: false,
      },
      lastMessage: {
        text: "Let me know when you're available for that video call we discussed.",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
        isRead: true,
      },
    },
  ]

  return (
    <div className="space-y-3">
      {chats.map((chat) => (
        <Card key={chat.id} className="overflow-hidden hover:bg-gray-50 transition-colors">
          <CardContent className="p-3">
            <Link href={`/dashboard/messages/${chat.id}`}>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img
                    src={chat.user.avatar || "/placeholder.svg"}
                    alt={chat.user.name}
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  {chat.user.online && (
                    <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-400 border-2 border-white"></span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between">
                    <p className="text-sm font-medium text-gray-900 truncate">{chat.user.name}</p>
                    <p className="text-xs text-gray-500">
                      {formatDistanceToNow(chat.lastMessage.timestamp, { addSuffix: true })}
                    </p>
                  </div>
                  <p
                    className={`text-sm truncate ${chat.lastMessage.isRead ? "text-gray-500" : "text-gray-900 font-medium"}`}
                  >
                    {chat.lastMessage.text}
                  </p>
                </div>
                {!chat.lastMessage.isRead && <div className="h-2 w-2 bg-purple-500 rounded-full"></div>}
              </div>
            </Link>
          </CardContent>
        </Card>
      ))}

      <Button variant="outline" className="w-full mt-4">
        View All Messages
      </Button>
    </div>
  )
}

