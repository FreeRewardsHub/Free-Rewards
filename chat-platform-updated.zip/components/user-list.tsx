import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MessageSquare, Video, UserPlus } from "lucide-react"

interface UserListProps {
  type: "suggestions" | "followers" | "following"
}

export default function UserList({ type }: UserListProps) {
  // This would normally come from an API
  const users = [
    {
      id: 1,
      name: "Emma Wilson",
      username: "@emmaw",
      avatar: "/placeholder.svg?height=50&width=50",
      bio: "Photographer and travel enthusiast",
      isFollowing: false,
    },
    {
      id: 2,
      name: "James Rodriguez",
      username: "@jamesr",
      avatar: "/placeholder.svg?height=50&width=50",
      bio: "Software engineer and coffee lover",
      isFollowing: true,
    },
    {
      id: 3,
      name: "Sophia Chen",
      username: "@sophiac",
      avatar: "/placeholder.svg?height=50&width=50",
      bio: "Artist and creative mind",
      isFollowing: false,
    },
    {
      id: 4,
      name: "Michael Brown",
      username: "@michaelb",
      avatar: "/placeholder.svg?height=50&width=50",
      bio: "Music producer and DJ",
      isFollowing: true,
    },
  ]

  return (
    <div className="space-y-4">
      {users.map((user) => (
        <Card key={user.id} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <img
                src={user.avatar || "/placeholder.svg"}
                alt={user.name}
                className="h-12 w-12 rounded-full object-cover"
              />
              <div className="flex-1 min-w-0">
                <Link href={`/profile/${user.id}`} className="hover:underline">
                  <p className="text-sm font-medium text-gray-900 truncate">{user.name}</p>
                </Link>
                <p className="text-sm text-gray-500 truncate">{user.username}</p>
                <p className="text-xs text-gray-600 mt-1 line-clamp-1">{user.bio}</p>
              </div>
              <div className="flex space-x-2">
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MessageSquare className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Video className="h-4 w-4" />
                </Button>
                <Button variant={user.isFollowing ? "outline" : "default"} size="sm" className="h-8">
                  {user.isFollowing ? (
                    "Following"
                  ) : (
                    <>
                      <UserPlus className="h-3 w-3 mr-1" /> Follow
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

