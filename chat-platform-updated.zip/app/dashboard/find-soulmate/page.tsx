"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Video, X, Mic, MicOff, VideoOff } from "lucide-react"

export default function FindSoulmatePage() {
  const [isSearching, setIsSearching] = useState(false);
  const [isMatched, setIsMatched] = useState(false);
  const [timeLeft, setTimeLeft] = useState(20);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);

  const startMatching = () => {
    setIsSearching(true);
    // Simulate finding a match after 3 seconds
    setTimeout(() => {
      setIsSearching(false);
      setIsMatched(true);
      
      // Start the countdown timer
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);\
            return  => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }, 3000);
  };

  const endCall = () => {
    setIsMatched(false);
    setTimeLeft(20);
  };

  const continueCall = () => {
    // This would normally redirect to a paid call feature
    alert("Continuing to paid call feature");
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const toggleVideo = () => {
    setIsVideoOff(!isVideoOff);
  };

  return (
    <div className="container mx-auto px-4 pt-24 pb-12 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6 text-center">Find Your Soulmate</h1>
      
      <Card className="overflow-hidden">
        <CardHeader className="text-center">
          <CardTitle>
            {!isMatched && !isSearching ? "Ready to Connect?" : 
             isSearching ? "Searching for your match..." : 
             `Free Preview: ${timeLeft}s remaining`}
          </CardTitle>
          <CardDescription>
            {!isMatched && !isSearching ? 
              "Click the button below to start a random video call and find your perfect match" : 
              isSearching ? 
                "We're looking for someone compatible with your profile" : 
                "If you both like each other, you can continue the conversation"}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          <div className="relative aspect-video bg-gray-900 overflow-hidden">
            {isSearching && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="animate-pulse">
                  <Heart className="h-20 w-20 text-pink-500" />
                </div>
              </div>
            )}
            
            {isMatched && (
              <>
                <div className="absolute inset-0">
                  <img 
                    src="/placeholder.svg?height=720&width=1280" 
                    alt="Video call" 
                    className="w-full h-full object-cover"
                  />
                </div>
                
                {/* Self view */}
                <div className="absolute bottom-4 right-4 w-1/4 aspect-video bg-gray-800 rounded-lg overflow-hidden border-2 border-white shadow-lg">
                  <img 
                    src="/placeholder.svg?height=180&width=320" 
                    alt="Your video" 
                    className={`w-full h-full object-cover ${isVideoOff ? 'opacity-0' : ''}`}
                  />
                  {isVideoOff && (
                    <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
                      <Video className="h-8 w-8 text-gray-400" />
                    </div>
                  )}
                </div>
                
                {/* Controls */}
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-4 bg-black/50 rounded-full px-4 py-2">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`rounded-full ${isMuted ? 'bg-red-500 text-white hover:bg-red-600' : 'bg-gray-800 text-white hover:bg-gray-700'}`}
                    onClick={toggleMute}
                  >
                    {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full bg-red-500 text-white hover:bg-red-600"
                    onClick={endCall}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`rounded-full ${isVideoOff ? 'bg-red-500 text-white hover:bg-red-600' : 'bg-gray-800 text-white hover:bg-gray-700'}`}
                    onClick={toggleVideo}
                  >
                    {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
                  </Button>
                </div>
                
                {/* Timer */}
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-black/50 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Preview ends in: {timeLeft}s
                </div>
              </>
            )}
            
            {!isMatched && !isSearching && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-r from-purple-600 to-pink-500">
                <Video className="h-16 w-16 text-white mb-4" />
                <p className="text-white text-xl font-medium mb-6">Start a random video call</p>
                <Button 
                  size="lg" 
                  className="bg-white text-purple-600 hover:bg-gray-100"
                  onClick={startMatching}
                >
                  <Heart className="mr-2 h-5 w-5" />
                  Find My Soulmate
                </Button>
              </div>
            )}
          </div>
        </CardContent>
        
        {isMatched && (
          <CardFooter className="flex justify-between p-6">
            <Button variant="outline" onClick={endCall}>
              End Call
            </Button>
            <Button onClick={continueCall}>
              Continue Call (Premium)
            </Button>
          </CardFooter>
        )}
      </Card>
      
      <div className="mt-8 bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="bg-purple-100 rounded-full p-4 inline-flex mb-3">
              <Heart className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="font-medium mb-2">1. Click Find Soulmate</h3>
            <p className="text-gray-600 text-sm">Start the matching process with a single click</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-100 rounded-full p-4 inline-flex mb-3">
              <Video className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="font-medium mb-2">2. Preview for 20 Seconds</h3>
            <p className="text-gray-600 text-sm">Get a free 20-second preview to see if you connect</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-100 rounded-full p-4 inline-flex mb-3">
              <Heart className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="font-medium mb-2">3. Continue if You Match</h3>
            <p className="text-gray-600 text-sm">If you both like each other, continue the conversation</p>
          </div>
        </div>
      </div>
    </div>
  );
}

