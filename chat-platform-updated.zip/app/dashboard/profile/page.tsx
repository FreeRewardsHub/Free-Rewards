"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Camera, Edit2, MapPin, Calendar, Briefcase, GraduationCap, Save } from "lucide-react"
import UserList from "@/components/user-list"

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)

  // This would normally come from an API
  const [profile, setProfile] = useState({
    name: "Alex Johnson",
    username: "@alexj",
    bio: "Software developer and photography enthusiast. Love to travel and explore new places.",
    location: "San Francisco, CA",
    birthday: "May 15, 1990",
    occupation: "Senior Developer at TechCorp",
    education: "Computer Science, Stanford University",
    followers: 1432,
    following: 248,
    posts: 87,
  })

  const handleSaveProfile = () => {
    // This would normally save to an API
    setIsEditing(false)
  }

  return (
    <div className="container mx-auto px-4 pt-24 pb-12 max-w-6xl">
      <Card>
        <div className="relative h-48 bg-gradient-to-r from-purple-600 to-pink-500 rounded-t-lg">
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 bg-black/20 text-white hover:bg-black/30"
          >
            <Camera className="h-5 w-5" />
          </Button>
        </div>

        <div className="px-6 pb-6">
          <div className="flex flex-col md:flex-row items-start md:items-end -mt-16 mb-6">
            <div className="relative">
              <div className="h-32 w-32 rounded-full border-4 border-white bg-white overflow-hidden">
                <img src="/placeholder.svg?height=128&width=128" alt="Profile" className="h-full w-full object-cover" />
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="absolute bottom-0 right-0 bg-gray-100 hover:bg-gray-200 rounded-full h-8 w-8"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>

            <div className="mt-4 md:mt-0 md:ml-6 flex-1">
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold">{profile.name}</h1>
                  <p className="text-gray-500">{profile.username}</p>
                </div>
                <div className="mt-4 md:mt-0">
                  {isEditing ? (
                    <Button onClick={handleSaveProfile}>
                      <Save className="h-4 w-4 mr-2" />
                      Save Profile
                    </Button>
                  ) : (
                    <Button variant="outline" onClick={() => setIsEditing(true)}>
                      <Edit2 className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              {isEditing ? (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={profile.name}
                      onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      value={profile.username}
                      onChange={(e) => setProfile({ ...profile, username: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      value={profile.bio}
                      onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                      rows={4}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={profile.location}
                        onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="birthday">Birthday</Label>
                      <Input
                        id="birthday"
                        value={profile.birthday}
                        onChange={(e) => setProfile({ ...profile, birthday: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="occupation">Occupation</Label>
                      <Input
                        id="occupation"
                        value={profile.occupation}
                        onChange={(e) => setProfile({ ...profile, occupation: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="education">Education</Label>
                      <Input
                        id="education"
                        value={profile.education}
                        onChange={(e) => setProfile({ ...profile, education: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  <p className="text-gray-700 mb-6">{profile.bio}</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div className="flex items-center text-gray-600">
                      <MapPin className="h-5 w-5 mr-2 text-gray-400" />
                      {profile.location}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Calendar className="h-5 w-5 mr-2 text-gray-400" />
                      {profile.birthday}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Briefcase className="h-5 w-5 mr-2 text-gray-400" />
                      {profile.occupation}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <GraduationCap className="h-5 w-5 mr-2 text-gray-400" />
                      {profile.education}
                    </div>
                  </div>

                  <div className="flex space-x-6 border-t border-b py-4 mb-6">
                    <div className="text-center">
                      <p className="text-2xl font-bold">{profile.posts}</p>
                      <p className="text-sm text-gray-500">Posts</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold">{profile.followers}</p>
                      <p className="text-sm text-gray-500">Followers</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold">{profile.following}</p>
                      <p className="text-sm text-gray-500">Following</p>
                    </div>
                  </div>
                </>
              )}

              <Tabs defaultValue="photos">
                <TabsList className="mb-4">
                  <TabsTrigger value="photos">Photos</TabsTrigger>
                  <TabsTrigger value="followers">Followers</TabsTrigger>
                  <TabsTrigger value="following">Following</TabsTrigger>
                </TabsList>
                <TabsContent value="photos">
                  <div className="grid grid-cols-3 gap-2">
                    {Array.from({ length: 9 }).map((_, i) => (
                      <div key={i} className="aspect-square bg-gray-100 rounded-md overflow-hidden">
                        <img
                          src={`/placeholder.svg?height=300&width=300&text=Photo ${i + 1}`}
                          alt={`Photo ${i + 1}`}
                          className="h-full w-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="followers">
                  <UserList type="followers" />
                </TabsContent>
                <TabsContent value="following">
                  <UserList type="following" />
                </TabsContent>
              </Tabs>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Premium Features</CardTitle>
                  <CardDescription>Upgrade to access exclusive features</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-purple-500 rounded-full mr-2"></span>
                      Unlimited video calls
                    </li>
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-purple-500 rounded-full mr-2"></span>
                      Advanced matching algorithm
                    </li>
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-purple-500 rounded-full mr-2"></span>
                      No ads experience
                    </li>
                    <li className="flex items-center">
                      <span className="h-2 w-2 bg-purple-500 rounded-full mr-2"></span>
                      Priority customer support
                    </li>
                  </ul>
                  <Button className="w-full">Upgrade to Premium</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}

