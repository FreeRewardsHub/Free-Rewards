import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Search, Plus, MessageSquare } from "lucide-react"
import RecentChats from "@/components/recent-chats"

export const metadata: Metadata = {
  title: "Messages | Connection Platform",
  description: "Chat with your connections",
}

export default function MessagesPage() {
  return (
    <div className="container mx-auto px-4 pt-24 pb-12 max-w-6xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Messages</h1>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          New Message
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input placeholder="Search messages" className="pl-10" />
            </div>
          </div>

          <div className="space-y-1">
            <RecentChats />
          </div>
        </div>

        <Card className="md:col-span-2 flex flex-col h-[600px] bg-gray-50">
          <div className="flex-1 flex items-center justify-center p-6 text-center">
            <div>
              <div className="bg-gray-100 rounded-full p-6 inline-flex mb-4">
                <MessageSquare className="h-10 w-10 text-gray-400" />
              </div>
              <h2 className="text-xl font-medium mb-2">Your Messages</h2>
              <p className="text-gray-500 mb-6 max-w-md">Select a conversation or start a new one to begin messaging</p>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Message
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

