"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Video, Phone, MoreHorizontal, Send, Paperclip, Smile } from "lucide-react"

export default function ChatPage({ params }: { params: { id: string } }) {
  const [message, setMessage] = useState("")

  // This would normally come from an API based on the ID
  const contact = {
    id: params.id,
    name: "Emma Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    online: true,
    lastSeen: "Active now",
  }

  // This would normally come from an API
  const messages = [
    {
      id: 1,
      sender: "them",
      text: "Hey there! How are you doing today?",
      timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
    },
    {
      id: 2,
      sender: "me",
      text: "I'm doing great, thanks for asking! Just finished a project I've been working on for weeks.",
      timestamp: new Date(Date.now() - 1000 * 60 * 55), // 55 minutes ago
    },
    {
      id: 3,
      sender: "them",
      text: "That's awesome! What kind of project was it?",
      timestamp: new Date(Date.now() - 1000 * 60 * 50), // 50 minutes ago
    },
    {
      id: 4,
      sender: "me",
      text: "It was a web application for a client. Lots of interactive features and real-time updates.",
      timestamp: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
    },
    {
      id: 5,
      sender: "them",
      text: "Sounds interesting! I've been thinking about learning web development myself.",
      timestamp: new Date(Date.now() - 1000 * 60 * 40), // 40 minutes ago
    },
    {
      id: 6,
      sender: "them",
      text: "Do you have any recommendations for where to start?",
      timestamp: new Date(Date.now() - 1000 * 60 * 39), // 39 minutes ago
    },
    {
      id: 7,
      sender: "me",
      text: "Definitely! I'd recommend starting with the basics - HTML, CSS, and JavaScript. There are tons of free resources online.",
      timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
    },
    {
      id: 8,
      sender: "me",
      text: "Once you're comfortable with those, you can move on to frameworks like React or Vue.",
      timestamp: new Date(Date.now() - 1000 * 60 * 29), // 29 minutes ago
    },
    {
      id: 9,
      sender: "them",
      text: "Thanks for the advice! I'll check those out.",
      timestamp: new Date(Date.now() - 1000 * 60 * 20), // 20 minutes ago
    },
    {
      id: 10,
      sender: "them",
      text: "Hey, are you free to video chat later today?",
      timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
    },
  ]

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (message.trim()) {
      // This would normally send the message to an API
      console.log("Sending message:", message)
      setMessage("")
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="container mx-auto px-4 pt-24 pb-12 max-w-6xl">
      <Card className="h-[calc(100vh-200px)] flex flex-col">
        <CardHeader className="border-b px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <img
                  src={contact.avatar || "/placeholder.svg"}
                  alt={contact.name}
                  className="h-10 w-10 rounded-full object-cover"
                />
                {contact.online && (
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-400 border-2 border-white"></span>
                )}
              </div>
              <div>
                <h2 className="text-base font-medium">{contact.name}</h2>
                <p className="text-xs text-gray-500">{contact.lastSeen}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" className="rounded-full">
                <Phone className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Video className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[70%] px-4 py-2 rounded-lg ${
                  msg.sender === "me"
                    ? "bg-purple-500 text-white rounded-br-none"
                    : "bg-gray-100 text-gray-800 rounded-bl-none"
                }`}
              >
                <p>{msg.text}</p>
                <p className={`text-xs mt-1 text-right ${msg.sender === "me" ? "text-purple-100" : "text-gray-500"}`}>
                  {formatTime(msg.timestamp)}
                </p>
              </div>
            </div>
          ))}
        </CardContent>

        <div className="border-t p-3">
          <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
            <Button type="button" variant="ghost" size="icon" className="text-gray-500">
              <Paperclip className="h-5 w-5" />
            </Button>
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1"
            />
            <Button type="button" variant="ghost" size="icon" className="text-gray-500">
              <Smile className="h-5 w-5" />
            </Button>
            <Button type="submit" size="icon" disabled={!message.trim()}>
              <Send className="h-5 w-5" />
            </Button>
          </form>
        </div>
      </Card>
    </div>
  )
}

