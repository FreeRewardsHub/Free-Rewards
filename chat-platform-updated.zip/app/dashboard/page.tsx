import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageSquare, Video, Users, Heart, Search, Bell, Menu } from "lucide-react"
import UserList from "@/components/user-list"
import RecentChats from "@/components/recent-chats"

export const metadata: Metadata = {
  title: "Dashboard | Connection Platform",
  description: "Your dashboard for managing connections and chats",
}

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex w-64 flex-col fixed inset-y-0 bg-white border-r border-gray-200 pt-16">
        <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
          <div className="flex-1 px-3 space-y-1">
            <Link
              href="/dashboard"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md bg-purple-50 text-purple-600"
            >
              <Users className="mr-3 h-5 w-5" />
              Dashboard
            </Link>
            <Link
              href="/dashboard/messages"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <MessageSquare className="mr-3 h-5 w-5" />
              Messages
            </Link>
            <Link
              href="/dashboard/video-calls"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <Video className="mr-3 h-5 w-5" />
              Video Calls
            </Link>
            <Link
              href="/dashboard/find-soulmate"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <Heart className="mr-3 h-5 w-5" />
              Find Soulmate
            </Link>
            <Link
              href="/dashboard/connections"
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <Users className="mr-3 h-5 w-5" />
              Connections
            </Link>
          </div>
        </div>
        <div className="p-4 border-t border-gray-200">
          <Link href="/dashboard/profile">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <img className="h-10 w-10 rounded-full" src="/placeholder.svg?height=40&width=40" alt="User profile" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700">Alex Johnson</p>
                <p className="text-xs text-gray-500">View Profile</p>
              </div>
            </div>
          </Link>
        </div>
      </div>

      {/* Main content */}
      <div className="md:pl-64 flex flex-col flex-1">
        <div className="sticky top-0 z-10 flex-shrink-0 flex h-16 bg-white shadow md:hidden">
          <div className="flex-1 px-4 flex justify-between">
            <div className="flex-1 flex items-center">
              <span className="text-xl font-bold">ConnectMe</span>
            </div>
            <div className="flex items-center">
              <button className="p-1 rounded-full text-gray-400 hover:text-gray-500 focus:outline-none">
                <Menu className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>

        <main className="flex-1 pb-8 pt-20">
          <div className="container mx-auto px-4 sm:px-6 md:px-8">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
              <div className="flex items-center space-x-4">
                <Button variant="outline" size="sm" className="hidden md:flex">
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Welcome Back, Alex!</CardTitle>
                  <CardDescription>Here's what's happening with your connections today.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="recent">
                    <TabsList className="mb-4">
                      <TabsTrigger value="recent">Recent Activity</TabsTrigger>
                      <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                    </TabsList>
                    <TabsContent value="recent">
                      <RecentChats />
                    </TabsContent>
                    <TabsContent value="suggestions">
                      <UserList type="suggestions" />
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Find Your Soulmate</CardTitle>
                    <CardDescription>Start a random video call and see if you connect!</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full" size="lg">
                      <Heart className="mr-2 h-4 w-4" />
                      Start Matching
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Your Network</CardTitle>
                    <CardDescription>Your followers and following</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between mb-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold">248</p>
                        <p className="text-sm text-gray-500">Following</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold">1,432</p>
                        <p className="text-sm text-gray-500">Followers</p>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full">
                      <Users className="mr-2 h-4 w-4" />
                      View All Connections
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

