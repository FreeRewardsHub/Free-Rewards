import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, MessageSquare, Video, Users, Heart } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-purple-600 to-pink-500 text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="md:w-1/2 space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold leading-tight animate-fade-in">
                Find Your Perfect Connection
              </h1>
              <p className="text-xl opacity-90 max-w-md animate-fade-in-delay">
                Connect with like-minded people through chat, video calls, and our unique matching system.
              </p>
              <div className="flex flex-wrap gap-4 pt-4 animate-fade-in-delay-2">
                <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
                  <Link href="/signup" className="flex items-center gap-2">
                    Get Started <ArrowRight size={18} />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  <Link href="/about">Learn More</Link>
                </Button>
              </div>
            </div>
            <div className="md:w-1/2 relative animate-float">
              <div className="relative w-full aspect-square max-w-md mx-auto">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full opacity-20 blur-3xl"></div>
                <img
                  src="/placeholder.svg?height=500&width=500"
                  alt="People connecting"
                  className="relative z-10 rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Connect Your Way</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <MessageSquare className="h-10 w-10 text-purple-500" />,
                title: "Chat Anytime",
                description: "Send messages and stay connected with people who matter to you.",
              },
              {
                icon: <Video className="h-10 w-10 text-purple-500" />,
                title: "Video Calls",
                description: "Face-to-face conversations with crystal clear video quality.",
              },
              {
                icon: <Heart className="h-10 w-10 text-purple-500" />,
                title: "Find Soulmate",
                description: "Our special matching system helps you find your perfect match.",
              },
              {
                icon: <Users className="h-10 w-10 text-purple-500" />,
                title: "Build Community",
                description: "Follow others and grow your network of connections.",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 flex flex-col items-center text-center"
              >
                <div className="mb-4 p-3 bg-purple-50 rounded-full">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Find Your Connection?</h2>
          <p className="text-xl opacity-90 max-w-2xl mx-auto mb-10">
            Join thousands of people who have already found meaningful connections on our platform.
          </p>
          <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
            <Link href="/signup" className="flex items-center gap-2">
              Create Your Account <ArrowRight size={18} />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-white transition-colors">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/press" className="hover:text-white transition-colors">
                    Press
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Features</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/features/chat" className="hover:text-white transition-colors">
                    Chat
                  </Link>
                </li>
                <li>
                  <Link href="/features/video" className="hover:text-white transition-colors">
                    Video Calls
                  </Link>
                </li>
                <li>
                  <Link href="/features/soulmate" className="hover:text-white transition-colors">
                    Find Soulmate
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Support</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/help" className="hover:text-white transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="hover:text-white transition-colors">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/terms" className="hover:text-white transition-colors">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/cookies" className="hover:text-white transition-colors">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p>© {new Date().getFullYear()} Connection Platform. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

